# ClinicFlow Calendar Page Handoff

This bundle captures the ClinicFlow frontend from the `Calendar` branch at commit
`75445e3` (`Created calendar and added other features`).

## What is included

- `frontend/src/App.tsx` — app shell and inline calendar page. The calendar state,
  date navigation, month/week/day views, sample appointment slots, and time picker
  are implemented here rather than in a separate calendar component.
- `frontend/src/App.css` — frontend styles, including the calendar and time-picker
  styles. The complete stylesheet is included because it shares global app styles.
- `frontend/src/` — remaining frontend components, services, and assets needed to
  understand the app context and imports.
- Frontend package/build configuration and lockfile.

The bundle intentionally excludes `.env.local`, other environment files,
`node_modules`, and native Android/iOS projects.

## Prototype behavior

The calendar page is a visual prototype. Its selected clinic and appointment
availability are local sample data in `App.tsx` (including dates in June 2025);
the calendar page does not load or book live appointments from Supabase. The
separate home-page booking flow is not the source of the calendar page's data.

## To use with ClinicFlow

Copy the included `frontend/src` files into the matching paths in a ClinicFlow
checkout, install frontend dependencies, and configure
`VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` in
`frontend/.env.local` before starting the app. Do not share real secrets or
patient data.
